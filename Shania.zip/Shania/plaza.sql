-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 02, 2020 at 07:21 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `plaza`
--

-- --------------------------------------------------------

--
-- Table structure for table `ricci_info`
--

CREATE TABLE `ricci_info` (
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `skills` text NOT NULL,
  `description` text NOT NULL,
  `motto` text NOT NULL,
  `about_me` text NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ricci_info`
--

INSERT INTO `ricci_info` (`fname`, `lname`, `skills`, `description`, `motto`, `about_me`, `email`) VALUES
('Shania Ricci', 'Plaza', 'cooking, baking, photo editing', 'I love to cook and to bake. I am also into photography, I like to edit photos that I personally taken and to explore many things, I used several apps for editing and also writing a poem. To be able to express my feelings through these is quite satisfying for myself. I am working as a Student Assisstant in Father Saturnino Urios University for almost 2 years now, it gives many lessons and different views on how real world works.', 'always appreciate small things', 'My name is Shania Plaza. I finished my junior and senior high school in Agusan National High School and Father Saturnino Urios University, Pueblos High School.', 'shanicci03@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
