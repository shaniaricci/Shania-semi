######## INSTALLATION FOR MY WEB APPLICATION ##############


STEP 1: YOU MUST IMPORT THE plaza.sql in localhost.
STEP 2: AFTER YOU UPLOADED THE FILE. THE DATABASE NAME IS "plaza" DATABASE TABLE IS "ricci_info".
STEP 3: NOW VISIT THIS LINK: http://localhost/Shania/Cont_plaza