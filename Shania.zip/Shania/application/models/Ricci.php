<?php  

defined('BASEPATH') OR exit('No direct script access allowed');


/**
 * summary
 */
class Ricci extends CI_Model
{
    /**
     * summary
     */
     public function getdata()
	    {
	    	$table = $this->db->table_exists('ricci_info');
	    	if ($table) {
	    		$que = $this->db->get('ricci_info');
	    		if ($que->num_rows() > 0) {
	    			return $que->result();
	    		}
	    		else{
	    			return false;
	    		}
	    	}
	    	else {
	    		return false;
	    	}
	    }
}

?>