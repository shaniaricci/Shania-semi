<?php  

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * summary
 */
class Cont_plaza extends CI_Controller
{
    /**
     * summary
     */

    function __construct(){
    	parent:: __construct();
    	$this->load->model('ricci','data');
    }

    function index(){
    	$data['tbl_pla'] = $this->data->getdata();
    	$this->load->view('main/index',$data);
    }

    function about(){
    	$data['tbl_about'] = $this->data->getdata();
    	$this->load->view('main/about',$data);
    }
    function skills(){
    	$data['tbl_skills'] = $this->data->getdata();
    	$this->load->view('main/skills',$data);
    }
    function personal(){
    	$data['tbl_per'] = $this->data->getdata();
    	$this->load->view('main/personal',$data);
    }
}

?>